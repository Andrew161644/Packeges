package com.example.Reactive.Docker

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ReactiveDockerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
